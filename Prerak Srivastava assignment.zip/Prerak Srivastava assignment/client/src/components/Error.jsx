import React from 'react'

const Error = () => {
  return (
    <div>
        <img src='https://gifimage.net/wp-content/uploads/2017/09/404-gif-1.gif' style={{height:'90vh', margin:'auto'}} alt='error' />
    </div>
  )
}

export default Error