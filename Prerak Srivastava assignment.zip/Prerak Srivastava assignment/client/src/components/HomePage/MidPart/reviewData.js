const reviwewData = [
  {
    title: "Great experience",
    disc: "It has really helped me become more organized.",
    author: "— Lauren Leonard, Illustrator",
  },
  {
    title: " Trackers don't get much better than",
    disc: "I track my time for all the tasks I perform; work-related and other.",
    author: "— Ivan Arsenov, Recruitment Manager",
  },
  {
    title: " Very useful and intuitive",
    disc: "Extremely comfortable. Ads free. Amazing in terms of customer support.",
    author: "— Ivan Napolskykh, Software Engineer,",
  },
  {
    title: "Clockify is scary good!",
    disc: "It is a powerful and often frightening insight into your own behavior.",
    author: "— Skyler Bird, Web Designer",
  },
  {
    title: "Seamless time tracking",
    disc: "Clockify is so easy to use and intuitive. The learning curve is almost none.",
    author: "— Sheila Zayas, Graphic Design",
  },
  {
    title: "Best time tracker",
    disc: "Clockify has become a basic in my set of freelance tools.",
    author: "— Luis Miguel Rivas Zepeda, Software Engineer",
  },
  {
    title: "One of the best values available online",
    disc: "Really good. Overall, this is a TREMENDOUS value for the price.",
    author: "— Patrick Carver, Entrepreneur",
  },
  {
    title: "Finally an intuitive online time logger",
    disc: "I like that it is available to me online and can use it wherever I am.",
    author: "— Michele Wong, Entrepreneur",
  },
  {
    title: "Amazing timer that gets the job done",
    disc: "Gives a very clear idea about where my time is being spent. It helps in self-development!",
    author: "— Anirudh Kshemendranath, Consulting Analyst",
  },
  {
    title: "Must-use productivity software",
    disc: "Time-tracking is smoother, productivity is easier.",
    author: "— Ellen Mubwanda, Copywriter",
  },
  {
    title: "May be the best time tracker there is!",
    disc: "Clockify has been an essential tool for our team to track time on a daily basis.",
    author: "— Camille Ang, Entrepreneur",
  },
  {
    title: "Works great for startups",
    disc: "We grew from a couple people to almost 80 and it worked perfectly the whole time!",
    author: "— Zachary Gaskill, Sales Manager",
  },
  {
    title: " Get much better than",
    disc: "I track my time for all the tasks I perform; work-related and other.",
    author: "— Ivan Arsenov, Recruitment Manager",
  },
  {
    title: " Useful and intuitive",
    disc: "Extremely comfortable. Ads free. Amazing in terms of customer support.",
    author: "— Ivan Napolskykh, Software Engineer,",
  },
  {
    title: "Scary good!",
    disc: "It is a powerful and often frightening insight into your own behavior.",
    author: "— Skyler Bird, Web Designer",
  }
];

export default reviwewData;
