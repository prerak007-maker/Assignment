import React from "react";
// import { SECONDPAGE_HOME_H2, SECONDPAGE_HOME_H1 } from "./Homecss";

function Part3() {
 
  return (
    <div style={{ marginTop: "50px" }}>
      <p  style={{ wordSpacing: "0.5rem", fontSize:'34px', fontWeight:'400', color:'black'}}>Time management features</p>
      <p  style={{ fontSize:'20.8px', marginTop:'10px', color:'#5a6b7b'}}>
        Track productivity, attendance, and billable hours with a simple <br />
        time tracker and timesheet.
      </p>
    </div>
  );
}

export default Part3;
