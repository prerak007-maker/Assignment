import React from 'react'
import img from '../../assets/img/MainComponentImages/reports.png'

const Reports = () => {
  return (
    <div>
      <img src={img} alt='' />
    </div>
  )
}

export default Reports