import React from 'react'
import setting from '../../assets/img/MainComponentImages/setting.png'

const Setting = () => {
  return (
    <div style={{width:'100%'}} >
        <img src={setting} style={{width:'100%'}} alt='setting'/>
    </div>
  )
}

export default Setting