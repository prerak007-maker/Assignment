import React from 'react'
import img from '../../assets/img/MainComponentImages/teams.png'

const Clients = () => {
  return (
    <div>
      <img src={img} alt='' />
    </div>
  )
}

export default Clients