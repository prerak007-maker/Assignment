import React from 'react'
import img from '../../assets/img/MainComponentImages/calendar.png'

const Calendar = () => {
  return (
    <div>
      <img src={img} alt='' />
    </div>
  )
}

export default Calendar