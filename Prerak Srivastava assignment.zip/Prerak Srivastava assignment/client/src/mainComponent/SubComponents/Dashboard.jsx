import React from 'react'
import img from '../../assets/img/MainComponentImages/dashboard.png'

const Dashboard = () => {
  return (
    <div>
      <img src={img} alt='' />
    </div>
  )
}

export default Dashboard