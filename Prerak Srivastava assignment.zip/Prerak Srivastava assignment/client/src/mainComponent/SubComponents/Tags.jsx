import React from 'react'
import img from '../../assets/img/MainComponentImages/calendar.png'

const Tags = () => {
  return (
    <div>
      <img src={img} alt='' />
    </div>
  )
}

export default Tags